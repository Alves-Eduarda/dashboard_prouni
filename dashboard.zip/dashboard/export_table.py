import pandas as pd
import numpy as np
from datetime import datetime

# leitura das tabelas

#dados do prouni
df_prouni_2018 =pd.read_csv(r"C:\Users\User\OneDrive\Acadêmico\espec_cesar_school\visualizacao_dados\dashboard\datasets\pda-prouni-2018.csv",sep=';',encoding='utf-8')
df_prouni_2019 =pd.read_csv(r"C:\Users\User\OneDrive\Acadêmico\espec_cesar_school\visualizacao_dados\dashboard\datasets\pda-prouni-2019.csv",sep=';',encoding='utf-8')
df_prouni_2020 = pd.read_csv(r"C:\Users\User\OneDrive\Acadêmico\espec_cesar_school\visualizacao_dados\dashboard\datasets\ProuniRelatorioDadosAbertos2020.csv",encoding='latin-1',sep=';')

# renomeação das colunas 
df_prouni_2018.rename(columns={'ï»¿ANO_CONCESSAO_BOLSA':'ANO_CONCESSAO_BOLSA','CPF_BENEFICIARIO_BOLSA':'CPF_BENEFICIARIO',
                        'SEXO_BENEFICIARIO_BOLSA':'SEXO_BENEFICIARIO','RACA_BENEFICIARIO_BOLSA':'RACA_BENEFICIARIO',
                        'DT_NASCIMENTO_BENEFICIARIO':'DATA_NASCIMENTO','REGIAO_BENEFICIARIO_BOLSA':'REGIAO_BENEFICIARIO',
                        'SIGLA_UF_BENEFICIARIO_BOLSA':'UF_BENEFICIARIO','MUNICIPIO_BENEFICIARIO_BOLSA':'MUNICIPIO_BENEFICIARIO',
                        },inplace=True)

df_prouni_2019.rename(columns={'ï»¿ANO_CONCESSAO_BOLSA':'ANO_CONCESSAO_BOLSA','CPF_BENEFICIARIO_BOLSA':'CPF_BENEFICIARIO',
                        'SEXO_BENEFICIARIO_BOLSA':'SEXO_BENEFICIARIO','RACA_BENEFICIARIO_BOLSA':'RACA_BENEFICIARIO',
                        'DT_NASCIMENTO_BENEFICIARIO':'DATA_NASCIMENTO','REGIAO_BENEFICIARIO_BOLSA':'REGIAO_BENEFICIARIO',
                        'SIGLA_UF_BENEFICIARIO_BOLSA':'UF_BENEFICIARIO','MUNICIPIO_BENEFICIARIO_BOLSA':'MUNICIPIO_BENEFICIARIO'
                        },inplace=True)

# realizando a concatenação das tabelas
df = pd.concat([df_prouni_2018,df_prouni_2019,df_prouni_2020])

# retirando as colunas de municipio e campus
df.drop(columns={'MUNICIPIO','CAMPUS'},inplace=True)

# retirando os valores nulos da tabela
df = df.dropna()

# convertendo o valor da coluna de DATA_NASCIMENTO para datetime
df['DATA_NASCIMENTO'] = df['DATA_NASCIMENTO'].astype('datetime64[ns]')

# deletando os valores duplicados
df.drop_duplicates(keep='first',inplace=True)

# modificando os valores da tabela para uppercase
df['REGIAO_BENEFICIARIO'] = df['REGIAO_BENEFICIARIO'].str.upper()
df['NOME_CURSO_BOLSA'] = df['NOME_CURSO_BOLSA'].str.upper()
df['MODALIDADE_ENSINO_BOLSA'] = df['MODALIDADE_ENSINO_BOLSA'].str.upper()
df['RACA_BENEFICIARIO'] = df['RACA_BENEFICIARIO'].str.replace('Ind¡gena','Indígena')

# dados do mec
df_mec_2018 = pd.read_excel(r"C:\Users\User\OneDrive\Acadêmico\espec_cesar_school\visualizacao_dados\dashboard\datasets\IGC_2018.xlsx")
df_mec_2019 = pd.read_excel(r"C:\Users\User\OneDrive\Acadêmico\espec_cesar_school\visualizacao_dados\dashboard\datasets\IGC_2019.xlsx")

# reajuste do nome das colunas na tabela do mec de 2019
df_mec_2019.columns = list(df_mec_2018.columns)

# trazendo as informações de nota MEC por ano
df_mec = df_mec_2019.merge(df_mec_2018[['Código da IES','IGC (Contínuo)','IGC (Faixa)']],how='left',on='Código da IES',suffixes=('_2019','_2018'))

# Selecionando as colunas que interessam ao dataframe
df_mec = df_mec[['Código da IES','Nome da IES','IGC (Contínuo)_2018','IGC (Faixa)_2018','IGC (Contínuo)_2019','IGC (Faixa)_2019']]

# Substituindo os valores SC por nulo
df_mec['IGC (Faixa)_2018'] = df_mec['IGC (Faixa)_2018'].replace('SC',np.nan)
df_mec['IGC (Faixa)_2019']  = df_mec['IGC (Faixa)_2019'].replace('SC',np.nan)

# Adicionando a informação de nota do MEC no dataset do prouni
df = df.merge(df_mec[['Código da IES','IGC (Contínuo)_2018','IGC (Faixa)_2018','IGC (Contínuo)_2019','IGC (Faixa)_2019']],
                left_on='CODIGO_EMEC_IES_BOLSA',right_on='Código da IES',how='left')

# criação da coluna STATUS_FAIXA_IGC
df['STATUS_FAIXA_IGC'] = np.where((df['IGC (Faixa)_2019'] != df['IGC (Faixa)_2018']),"ICG DIFERENTE","IGC IGUAL")


# retirando outliers do dataset

df['IDADE'] = 2020 - df['DATA_NASCIMENTO'].dt.year
df = df[df['IDADE'] >= 14]

# export das tabelas
df.to_excel(r"datasets\tabela_prouni_mec.xlsx",sheet_name='base',index=False)