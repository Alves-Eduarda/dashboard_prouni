# importar as bibliotecas
import gc  # Coletor de lixo para liberar memória
import json
import unicodedata
import geopandas as gpd
import matplotlib.pyplot as plt
import pandas as pd
import plotly.express as px
import seaborn as sns
import streamlit as st
from shapely.geometry import Point

# variáveis globais
TIPO_ESTADOS = 0
TIPO_MUNICIPIOS = 1
tipo_grafico = TIPO_ESTADOS
titulo = 'Sem título'

gdf_uf_br = None
gdf_mun_br = None

# configuações da página
st.set_page_config(page_title="Dashboard Prouni", layout="wide")
hide_sidebar = """
    <style>
        [data-testid="stSidebarNav"] {display: none;}
    </style>
"""
st.markdown(hide_sidebar, unsafe_allow_html=True)

# Carregar os dados (substitua pelo seu arquivo)
try:
    #df = pd.read_excel(r'datasets/tabela_prouni_mec.xlsx',sheet_name='base')
    df = pd.read_excel(r'datasets/tabela_prouni_mec.xlsx',sheet_name='base')
except FileNotFoundError:
    st.error("Arquivo 'seu_arquivo.xlsx' não encontrado. Certifique-se de que o arquivo está no mesmo diretório ou especifique o caminho correto.")
    st.stop()

# Título do Dashboard
st.title("Dados do Prouni 2018 a 2020")

# Preparação do sidebar
with st.sidebar:
    le, mid, ri = st.columns(3)
    mid.image("assets/logo_cesar.png", width=100)

# criação do filtro da idade
age, age1 = st.sidebar.slider("Idade do Beneficiário", 0, 130,(18,25))
idades = [i for i in range(age,age1+1,1)]

# Insight 01
# lendo os dados com o geopandas
if gdf_uf_br == None:
  print('Lendo gdf_uf_br ...')
  gdf_uf_br = gpd.read_file(r'datasets\BR_UF_2022\BR_UF_2022.shp')

# Converter nome da região para maiúsculas
gdf_uf_br['NM_REGIAO'] = gdf_uf_br['NM_REGIAO'].apply(lambda nome: str.upper(nome))

# Remover os "\n"
gdf_uf_br['NM_REGIAO'] = gdf_uf_br['NM_REGIAO'].str.rstrip('\n')

# Alterar o nome da coluna
gdf_uf_br.rename(columns={'NM_UF':'NOME'}, inplace=True)

## Carregando as informações sobre os municípios (e suas coordenadas do mapa)
# lendo os dados com o geopandas
gdf_mun_br = gpd.read_file(r'datasets\BR_Municipios_2022\BR_Municipios_2022.shp')

gdf_mun_br['NM_MUN'] = gdf_mun_br['NM_MUN'].apply(lambda nome: str.upper(nome))

# Função para remover acentos
def remover_acentos(texto):
    return "".join(
        c for c in unicodedata.normalize("NFD", texto) if unicodedata.category(c) != "Mn"
    )

# Aplicar a função à coluna do DataFrame
gdf_mun_br["NM_MUN"] = gdf_mun_br["NM_MUN"].apply(remover_acentos)

# Criar coluna para join com uf + município
gdf_mun_br['UF_MUNICIPIO'] = gdf_mun_br['SIGLA_UF'] + ' - ' + gdf_mun_br['NM_MUN']

# Criar coluna para join com uf + município
df['UF_MUNICIPIO'] = df['UF_BENEFICIARIO'] + ' - ' + df['MUNICIPIO_BENEFICIARIO']

# Alterar o nome da coluna
gdf_mun_br.rename(columns={'NM_MUN':'NOME'}, inplace=True)

# VARIÁVEIS DAS METRICAS
regiao_para_ufs = {
    regiao: list(gdf_uf_br[gdf_uf_br['NM_REGIAO'] == regiao]['SIGLA_UF'].unique())
    for regiao in gdf_uf_br['NM_REGIAO'].unique()
}

# Filtro por Região
regioes_options = sorted(gdf_uf_br['NM_REGIAO'].unique())
#selected_regioes = st.sidebar.multiselect("Região", options=regioes_options, default=regioes_options)
selected_regioes = st.sidebar.multiselect("Região", options=regioes_options, default=['NORDESTE'])
# Tratar o caso de nenhuma opção ser selecionada (vazio)

if selected_regioes == []:
  # Habilitar todas as regiões
  selected_regioes = regioes_options

# UFs correspondentes às regiões selecionadas
ufs_selecionadas = []
for regiao in selected_regioes:
    ufs_selecionadas.extend(regiao_para_ufs[regiao])

# Filtro por UF (com base nas regiões selecionadas)
uf_options = sorted(gdf_uf_br['SIGLA_UF'].unique())

# Garante que apenas as UFs das regiões selecionadas sejam exibidas como padrão
if (len(selected_regioes) == 1) and (selected_regioes[0] == 'NORDESTE'):
  default_uf = ['PE']
else:
  default_uf = [uf for uf in uf_options if uf in ufs_selecionadas]

selected_ufs = st.sidebar.multiselect("UF", options=ufs_selecionadas, default=default_uf)
#selected_ufs = st.sidebar.multiselect("UF", options=default_uf, default=['PE'])

if selected_ufs == []:
  # Habilitar todas as UFs
  selected_ufs = uf_options

# Filtro por Ano da Bolsa
ano_options = sorted(df['ANO_CONCESSAO_BOLSA'].unique())
selected_anos = st.sidebar.multiselect("Ano da Bolsa", options=ano_options, default=ano_options)

if selected_anos == []:
  # Habilitar todos os anos
  selected_anos = ano_options

#--- APLICAR FILTROS
df_filtered = None
gdf_mapas = None

def aplicar_filtros(regioes: list[str], ufs: list[str], anos: list[int]):
    global tipo_grafico
    global titulo
    #print('Parâmetros recebidos em aplicar_filtros():')
    #print(regioes, ufs, anos)

    # Aplicando filtros ao Dataframe
    df_filtered = df[
        (df['UF_BENEFICIARIO'].isin(selected_ufs)) &
        (df['REGIAO_BENEFICIARIO'].isin(selected_regioes)) &
        (df['ANO_CONCESSAO_BOLSA'].isin(selected_anos)) &
        (df['IDADE'].isin(idades))
    ]

    
    # Selecionar o DataFrame de estados ou municípios
    if (len(regioes) == 1) and (len(ufs) == 1): # Municípios
    #print('Entrou em Municípios: ', regioes[0], ufs[0], anos[0])
        tipo_grafico = TIPO_MUNICIPIOS
        titulo = 'Distribuição de bolsas por município'
        gdf_mapa = gdf_mun_br[gdf_mun_br['SIGLA_UF'] == ufs[0]].copy()

        # Inserir a quantidade de bolsas
        df_aux = df_filtered.groupby(['UF_MUNICIPIO']).size().reset_index(name='Bolsas')
        gdf_mapa = gdf_mapa.merge(df_aux, left_on="UF_MUNICIPIO", right_on="UF_MUNICIPIO", how="left").fillna(0)

    else: # Estados
    #print('Entrou em Estados!')
        tipo_grafico = TIPO_ESTADOS
        titulo = 'Distribuição de bolsas por estado'
        gdf_mapa = gdf_uf_br.copy()

        # Inserir a quantidade de bolsas
        df_aux = df_filtered.groupby('UF_BENEFICIARIO').size().reset_index(name='Bolsas')

        # Mesclar os dados com o mapa do Brasil
        gdf_mapa = gdf_mapa.merge(df_aux, left_on="SIGLA_UF", right_on="UF_BENEFICIARIO", how="left").fillna(0)
        gdf_mapa = gdf_mapa.drop(columns=['UF_BENEFICIARIO'])

    return (df_filtered, gdf_mapa)

df_filtered, gdf_mapas = aplicar_filtros(selected_regioes, selected_ufs, selected_anos)
#df_filtered, gdf_mapas = aplicar_filtros(['NORDESTE'], ['RN'], [2020])

# Indicadores
total_bolsas = len(df_filtered)
regiao_mais_bolsas = df_filtered['REGIAO_BENEFICIARIO'].value_counts().idxmax()
contagem_sexo = df_filtered['SEXO_BENEFICIARIO'].value_counts()
bolsas_feminino = contagem_sexo.get('F', 0)
bolsas_masculino = contagem_sexo.get('M', 0)

col1, col2, col3, col4 = st.columns(4)
col1.metric("Total de Bolsas Ofertadas 📚", total_bolsas)
col2.metric("Região com Mais Bolsas 🌎", regiao_mais_bolsas)
col3.metric("Bolsas por Sexo Feminino 👩‍🎓", f"{bolsas_feminino}")
col4.metric("Bolsas por sexo Masculino 🧑‍🎓",f"{bolsas_masculino}")

st.header(f"{titulo}")

# salvar o geodataframe com formato geojson
filename = r'datasets\gdf.geojson'
gdf_mapas.to_file(filename, driver='GeoJSON')

# Carregar o arquivo GeoJSON
with open(r'datasets\gdf.geojson', "r", encoding="utf-8") as f:
    geojson_data = json.load(f)

# Criar o mapa interativo com Plotly
if tipo_grafico == TIPO_ESTADOS:
  #print('Gerando gráfico dos estados')
  fig = px.choropleth(
      gdf_mapas,
      geojson=geojson_data,
      locations="SIGLA_UF",
      featureidkey="properties.SIGLA_UF",
      color="Bolsas",  # Define a cor com base na coluna "total"
      color_continuous_scale="YlOrRd",
      title=None,
      labels={"Bolsas": "Nº de Bolsas", "SIGLA_UF": "UF"}
  )
else: # Municípios
  #print('Gerando gráfico dos municípios')
  #try:
  #   print(gdf_mapas[['NOME','Bolsas']])
  #except e:
  #   print('Excessão !')
  fig = px.choropleth(
    gdf_mapas,
    geojson=geojson_data,
    locations="NOME",
    featureidkey="properties.NOME",
    color="Bolsas",  # Define a cor com base na coluna "total"
    color_continuous_scale="YlOrRd",
    title=None,
    labels={"Bolsas": "Nº de Bolsas", "NOME": "Município"}
  )
fig.update_geos(fitbounds="locations", visible=False)
#fig.update_layout(coloraxis_colorbar=dict(title="Nº de Bolsas"))
# Ajustar tamanho da figura e zoom
fig.update_layout(
   coloraxis_colorbar=dict(title="Nº de Bolsas"),
    width=1000,  # Define a largura 1000
    height=700,  # Define a altura 7000
    geo=dict(projection_scale=2.5)  # Ajusta o zoom
)


# Exibir o mapa no Streamlit
st.plotly_chart(fig, use_container_width=False)

# Removendo od DataFrames para liberando memória
del gdf_uf_br
del gdf_mun_br
gc.collect()


#Insight 02
with st.container():
    st.header("Distribuição de bolsas por sexo") 
    # st.write("""O gráfico de pizza mostra a proporção geral de beneficiários do sexo feminino e masculino, considerando apenas os 5 cursos com maior número de beneficiários.
    #             O gráfico de barras empilhadas mostra a distribuição de bolsas por sexo (feminino e masculino) nos 5 cursos com o maior número de beneficiários.""" )
    col1, col2 = st.columns([1, 1.5]) #Mudar largura das colunas
    col1.write("O gráfico de pizza mostra a proporção geral de beneficiários do sexo feminino e masculino, considerando apenas os 5 cursos com maior número de beneficiários")
    col2.write(" O gráfico de barras empilhadas mostra a distribuição de bolsas por sexo (feminino e masculino) nos 5 cursos com o maior número de beneficiários")

    with col2:
        st.write("**Bolsas por Sexo (Top 5 Cursos)**")
        top_10_cursos = df_filtered['NOME_CURSO_BOLSA'].value_counts().head(5).index
        df_top_cursos = df_filtered[df_filtered['NOME_CURSO_BOLSA'].isin(top_10_cursos)]
        dados_grafico = df_top_cursos.groupby(['NOME_CURSO_BOLSA', 'SEXO_BENEFICIARIO']).size().reset_index(name='TOTAL')

        cursos_ordenados = df_top_cursos['NOME_CURSO_BOLSA'].value_counts().index

        cores = {'F': '#ff0092', 'M': '#228dff'}

        fig = px.bar(
            dados_grafico,
            x='NOME_CURSO_BOLSA',
            y='TOTAL',
            color='SEXO_BENEFICIARIO',
            barmode='stack',
            color_discrete_map=cores,  # Mapeia as cores para F e M
            category_orders={'NOME_CURSO_BOLSA': cursos_ordenados.tolist()},
            template='plotly_white',
            text='TOTAL'
        )
        fig.update_layout(showlegend=False, margin=dict(t=0, b=0, r=0), title=None, xaxis_title=None,
            yaxis_title=None)
        
        st.plotly_chart(fig)
    
    with col1:
        st.write("**Proporção de Beneficiários por Sexo (Top 5 Cursos)**") 
        st.write("""          """)
        dados_grafico = df_top_cursos['SEXO_BENEFICIARIO'].value_counts().reset_index()
        dados_grafico.columns = ['Sexo', 'Número de Beneficiários']
        fig = px.pie(dados_grafico,
             names='Sexo',
             values='Número de Beneficiários',
             template='plotly_white', 
             color_discrete_sequence=['#ff0092', '#228dff']
             )
        fig.update_layout(
            title=None,  
            showlegend=False,  
            margin=dict(l=0, r=0, t=0,b=0),  
            height=230, width=230 ,
            xaxis_title=None,
            yaxis_title=None
        )

        st.plotly_chart(fig)


# insight 3
st.header("Quantidade de bolsas por faixa etária")

# Adicionando a coluna GP_IDADE para o gráfico
bins = [0, 20, 40, 60, 80, 100]
intervalos = ['0-20', '21-40', '41-60', '61-80', '81-100']
df_filtered['GP_IDADE'] = pd.cut(df_filtered['IDADE'], bins=bins, labels=intervalos, right=True)


# Contagem de beneficiários por região e faixa etária
cont_regiao_idades = df_filtered.groupby(['REGIAO_BENEFICIARIO', 'GP_IDADE'])['REGIAO_BENEFICIARIO'].count().reset_index(name='Quantidade')

# Gráfico de barras (horizontal) com uma paleta de tons de azul mais variados
fig_3 = px.bar(
    cont_regiao_idades,
    x='Quantidade',
    y='REGIAO_BENEFICIARIO',
    color='GP_IDADE',
    text='Quantidade',
    orientation='h',
    color_discrete_sequence=px.colors.sequential.OrRd  # Paleta de cores de azuis mais escuros e claros
)

# Melhorando a aparência do gráfico
fig_3.update_layout(
    xaxis_title="Quantidade de Beneficiários",  # Título do eixo X
    yaxis_title="Região Beneficiária",  # Título do eixo Y
    font=dict(size=12, family="Arial, sans-serif"),  # Fonte dos rótulos
    xaxis=dict(
        zeroline=False,  # Não mostrar a linha zero
        tickangle=0,  # Manter os rótulos do eixo X horizontais
        showline=True,  # Mostrar linha de eixo X
        linecolor='gray'  # Cor da linha de eixo X
    ),
    yaxis=dict(
        showgrid=False,  # Remover linhas de grid do eixo Y
        showline=False,  # Remover linha do eixo Y
        tickangle=0,  # Manter os rótulos do eixo Y horizontais
        showticklabels=False  # Remove os rótulos do eixo Y (Região por Beneficiário)
    ),
    coloraxis_showscale=True  # Mostrar escala de cores
)

# Ajustar as margens para melhorar o layout
fig_3.update_layout(
    margin=dict(l=50, r=50, t=50, b=50),
    title=".",
    title_font=dict(
        size=20,  # Font size
        family="Arial, sans-serif",  # Font family
        color="white"  # Font color (can use color names or hex codes)
    ),
    yaxis=dict(showticklabels=True),
    xaxis_title=None,
    yaxis_title=None)

# Exibir o gráfico no Streamlit
st.plotly_chart(fig_3, use_container_width=True)

# Rodapé
footer_html = """
<style>
.footer {
    style= display: none;
    position: relative;
    bottom: 0;
    left: 0;
    width: 100%;
    background-color: #fa7b14;
    text-align: center;
    padding: 10px;
    font-size: 14px;
    color: white;
    font-weight: bold;
}
</style>
<div class="footer">
    Atividade 3 - Dashboard com Streamlit | 
    Link para a fonte de dados: <a href="pag_link" target="_blank">AQUI</a>
    
</div>

"""

st.markdown(footer_html, unsafe_allow_html=True)