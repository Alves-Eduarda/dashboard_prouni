import streamlit as st


st.set_page_config(page_title="Fontes", layout="wide")

hide_sidebar = """
    <style>
        [data-testid="stSidebarNav"] {display: none;}
    </style>
"""
st.markdown(hide_sidebar, unsafe_allow_html=True)

st.title("Link das Fontes")
fonts = ("1. https://www.google.com/url?q=https%3A%2F%2Fdados.gov.br%2Fdados%2Fconjuntos-dados%2Fmec-prouni\n"
"2. https://www.google.com/url?q=https%3A%2F%2Frevistaensinosuperior.com.br%2F2024%2F10%2F03%2Fead-alcancou-492-do-total-de-matriculas-em-2023%2F%23%3A%7E%3Atext%3DEm%25202023%252C%2520no%2520Brasil%252C%2520o%2Canual%2520de%25203%252C2%2525\n"
"3. https://www.google.com/url?q=https%3A%2F%2Fwww.gov.br%2Finep%2Fpt-br%2Fassuntos%2Fnoticias%2Fcenso-da-educacao-superior%2Fensino-a-distancia-cresce-474-em-uma-decada%23%3A%7E%3Atext%3DEntre%25202020%2520e%25202021%252C%2520o%2Cpresenciais%2520reduziu%252016%252C5%2525\n"
"4. https://abmes.org.br/noticias/detalhe/3355/metade-das-bolsas-integrais-do-prouni-e-em-cursos-a-distancia\n"
"5. https://www.opresente.com.br/geral/cerca-de-72-dos-moradores-da-regiao-sul-do-brasil-se-declaram-brancos/\n"
"6. https://vestibular.brasilescola.uol.com.br/noticias/censo-da-educacao-superior-mostra-que-ensino-a-distancia-cresceu-474-em-uma-decada/353431.html"
)

st.write(fonts)

with st.sidebar:
    _, mid,_ = st.columns(3)
    mid.image("assets/logo_cesar.png", width=100)

# Rodapé
footer_html = """
<style>
.footer {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    background-color: #fa7b14;
    text-align: center;
    padding: 10px;
    font-size: 14px;
    color: white;
    font-weight: bold;
}
</style>
<div class="footer">
    Atividade 3 - Dashboard com Streamlit
</div>
"""
st.markdown(footer_html, unsafe_allow_html=True)